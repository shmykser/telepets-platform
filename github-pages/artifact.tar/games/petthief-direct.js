import{c as e,n as i}from"./assets/PetThiefScene-BhscTGcS.js";window.Phaser=e;window.PetThiefScene=i;console.log("🎮 [PetThief Direct] Модули загружены и экспортированы в window");
